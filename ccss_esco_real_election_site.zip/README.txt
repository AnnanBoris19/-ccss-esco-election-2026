# CCSS ESCO Online Election — Real Website Starter

Files:
- index.html = member voting portal
- admin.html = electoral committee dashboard
- supabase_schema.sql = database schema/RPC
- README.txt = setup notes

The site is mobile-first and designed to be opened from WhatsApp in Safari/Chrome.

## Put it online
1. Create a Supabase project.
2. Run supabase_schema.sql in Supabase SQL Editor.
3. Create an election and positions/candidates/voters in the database.
4. Create an admin Auth user for the Electoral Committee.
5. Put the Supabase project URL and anon public key into BOTH index.html and admin.html.
6. Upload index.html and admin.html to GitHub.
7. Enable GitHub Pages from Settings > Pages > Deploy from branch (main/root).
8. Your public URL will look like https://USERNAME.github.io/ccss-esco-election/

## Security warning
Do not use this starter for a real election until voter verification is hardened server-side.
The final production version should verify voter codes through a server-side RPC/Edge Function
and should keep the voter register inaccessible to arbitrary public SELECT queries. Ballots are
submitted through a server-side transaction and are not directly insertable by the browser.

Mbenkum Estelle Diana is included as the initial President candidate in the front-end demo.
Replace the demo configuration with the actual election data before opening voting.
