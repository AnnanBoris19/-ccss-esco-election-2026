-- CCSS ESCO REAL ELECTION DATABASE (Supabase/Postgres)
create extension if not exists pgcrypto;

create table if not exists elections(
 id uuid primary key default gen_random_uuid(),
 name text not null,
 is_open boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists voters(
 id uuid primary key default gen_random_uuid(),
 election_id uuid not null references elections(id) on delete cascade,
 voter_code text not null,
 name text not null,
 has_voted boolean not null default false,
 unique(election_id,voter_code)
);
create table if not exists positions(
 id uuid primary key default gen_random_uuid(),
 election_id uuid not null references elections(id) on delete cascade,
 slug text not null,
 name text not null,
 unique(election_id,slug)
);
create table if not exists candidates(
 id uuid primary key default gen_random_uuid(),
 position_id uuid not null references positions(id) on delete cascade,
 name text not null,
 bio text default ''
);
create table if not exists ballots(
 id uuid primary key default gen_random_uuid(),
 election_id uuid not null references elections(id) on delete cascade,
 voter_id uuid not null unique references voters(id) on delete restrict,
 receipt text not null unique,
 choices jsonb not null,
 submitted_at timestamptz not null default now()
);

alter table elections enable row level security;
alter table voters enable row level security;
alter table positions enable row level security;
alter table candidates enable row level security;
alter table ballots enable row level security;

-- Voters may look up only the minimum record needed for verification.
create policy "voter verification" on voters for select to anon using (true);

-- Public election/ballot configuration.
create policy "public open elections" on elections for select to anon using (is_open=true);
create policy "public positions" on positions for select to anon using (true);
create policy "public candidates" on candidates for select to anon using (true);

-- Ballots are NOT directly insertable by the browser.
-- The RPC performs the transaction server-side.
create or replace function cast_ballot(p_voter_id uuid,p_election_id uuid,p_choices jsonb,p_receipt text)
returns void language plpgsql security definer set search_path=public
as $$
begin
 if not exists(select 1 from elections where id=p_election_id and is_open=true) then raise exception 'Election closed'; end if;
 if not exists(select 1 from voters where id=p_voter_id and election_id=p_election_id and has_voted=false) then raise exception 'Voter not eligible or already voted'; end if;
 insert into ballots(election_id,voter_id,receipt,choices) values(p_election_id,p_voter_id,p_receipt,p_choices);
 update voters set has_voted=true where id=p_voter_id;
end; $$;
revoke all on function cast_ballot(uuid,uuid,jsonb,text) from public;
grant execute on function cast_ballot(uuid,uuid,jsonb,text) to anon,authenticated;

-- IMPORTANT: For a real deployment, tighten voter SELECT access so it cannot expose
-- the full voter register. Use an Edge Function or a server-side verification RPC
-- before the real election. This starter schema is intentionally marked as needing
-- that final hardening step.
